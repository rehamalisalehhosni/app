var application = require("application");
application.start({ moduleName: "pages/home/home" });
