var BasePage = require("../../shared/BasePage");
var topmost = require("ui/frame").topmost;

var observableModule = require("data/observable");
var source = new observableModule.Observable();
source.textSource = "Text set via twoWay binding";
source.searchShow = false;

var HomePage = function() {};
HomePage.prototype = new BasePage();
HomePage.prototype.constructor = HomePage;
var frameModule =require("ui/frame");
// Place any code you want to run when the home page loads here.
HomePage.prototype.contentLoaded = function(args) {
  var page = args.object;
  page.bindingContext = source;
}

HomePage.prototype.fun = function() {
  var page = topmost().currentPage;
  var logo = page.getViewById("logo");
  logo.animate({
    rotate: 3600,
    duration: 3000
  }).then(function() {
    logo.rotate = 0;
  });
}

HomePage.prototype.onNavigatingTo=function(args) {
  var page = args.object;
  page.bindingContext = createViewModel();
}
HomePage.prototype.toggleSearch=function(args){
  var page = args.object;
  source.set("searchShow", !source.get("searchShow"));
}
HomePage.prototype.changePage=function() {
  // console.log("Navigating");
  var navigationOptions={
    moduleName:'pages/about/about',
    context:{param1: "value1",
    param2: "value2"
  }
}
frameModule.topmost().navigate(navigationOptions);
}
module.exports = new HomePage();
