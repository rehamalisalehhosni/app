var BasePage = require("../../shared/BasePage");

var AboutPage = function() {
  var page = args.object;

  var gotData=page.navigationContext;
  console.log(gotData.param1);
  console.log(gotData.param2);
};
AboutPage.prototype = new BasePage();
AboutPage.prototype.constructor = AboutPage;


module.exports = new AboutPage();
