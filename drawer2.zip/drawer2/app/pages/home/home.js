var BasePage = require("../../shared/BasePage");

var HomePage = function() {
};
AboutPage.prototype = new BasePage();
AboutPage.prototype.constructor = AboutPage;

AboutPage.prototype.onNavigatingTo=function(args) {
  var page = args.object;

  var gotData=page.navigationContext;
  console.log(gotData.param1);
  console.log(gotData.param2);

}


module.exports = new HomePage();
