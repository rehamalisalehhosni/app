var topmost = require("ui/frame").topmost;
var Observable = require("data/observable").Observable;
var drawerModule = require("nativescript-telerik-ui/sidedrawer");

var appViewModel = new Observable();
appViewModel.selectedPage = "home";
appViewModel.dataDrawer = "hidden";
appViewModel.dataDrawerLeft = "show";

function BasePage() {}
BasePage.prototype.viewModel = appViewModel
BasePage.prototype.pageLoaded = function(args) {
  var page = args.object;
  page.bindingContext = appViewModel;
}
BasePage.prototype.toggleDrawer = function() {
  var page = topmost().currentPage;
  page.getViewById("drawer").setDrawerLocation(drawerModule.SideDrawerLocation.Right);

  page.getViewById("drawer").toggleDrawerState();
  appViewModel.set("dataDrawer","hidden") ;
  appViewModel.set("dataDrawerLeft","show") ;

}
BasePage.prototype.toggleDrawerLeft = function() {
  var page = topmost().currentPage;
  page.getViewById("drawer").setDrawerLocation(drawerModule.SideDrawerLocation.Left);

  page.getViewById("drawer").toggleDrawerState();
  
  appViewModel.set("dataDrawer","show") ;
  appViewModel.set("dataDrawerLeft","hidden") ;
}
BasePage.prototype.navigate = function(args) {
  var pageName = args.view.text.toLowerCase();
  appViewModel.set("selectedPage", pageName);
  topmost().navigate("pages/" + pageName + "/" + pageName);
}

module.exports = BasePage;
