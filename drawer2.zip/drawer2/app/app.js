var application = require("application");
application.start({ moduleName: "pages/about/about" });
